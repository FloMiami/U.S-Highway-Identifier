import java.util.Scanner;
public class Highways {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter an Interstate highway number: ");
        int highwayNumber = input.nextInt();

        String result = checkInterstate(highwayNumber);
        System.out.println(result);
    }

    public static String checkInterstate(int highwayNumber) {
        if (highwayNumber >= 1 && highwayNumber <= 99) {
            return "I-" + highwayNumber + " is primary, going " + (highwayNumber % 2 == 0 ? "east/west." : "north/south.");
        } else if (highwayNumber >= 100 && highwayNumber <= 999) {
            int primaryHighway = highwayNumber % 100;
            if (primaryHighway >= 1 && primaryHighway <= 99) {
                return "I-" + highwayNumber + " is auxiliary, serving I-" + primaryHighway + ", going " + (primaryHighway % 2 == 0 ? "east/west." : "north/south.");
            }
        }
        return highwayNumber + " is not a valid interstate highway number.";
    }
}
